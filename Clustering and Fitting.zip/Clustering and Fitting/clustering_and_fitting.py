import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as ss
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.linear_model import LinearRegression


def plot_relational_plot(df):
    """
    Plots a simple scatter plot to visualize the relationship between two features in the dataset.

    Parameters:
        df (pd.DataFrame): The dataset containing the features and target column.

    Saves:
        Saves the plot as 'relational_plot.png'.
    """
    # Check if the necessary columns are in the DataFrame
    if 'sepal length' not in df.columns or 'sepal width' not in df.columns or 'class' not in df.columns:
        raise ValueError("Dataset must contain 'sepal length', 'sepal width', and 'class' columns.")

    # Choose two features for the scatter plot (example: 'sepal length' vs 'sepal width')
    feature1 = 'sepal length'
    feature2 = 'sepal width'

    # Create the scatter plot
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=df, x=feature1, y=feature2, hue='class', palette='Set1')

    # Add labels and title
    plt.title(f'Relationship between {feature1} and {feature2}')
    plt.xlabel(f'{feature1}')
    plt.ylabel(f'{feature2}')

    # Save the plot as a PNG file
    plt.savefig('relational_plot.png')
    plt.close()


def plot_categorical_plot(df):
    """
    Plots a bar plot to visualize the distribution of the target variable 'class'.

    Parameters:
        df (pd.DataFrame): The dataset for plotting, including the target column 'class'.

    Saves:
        Saves the plot as 'categorical_plot.png'.
    """
    plt.figure(figsize=(8, 6))
    sns.countplot(x='class', data=df)

    plt.title('Distribution of Target Variable (Class)')
    plt.xlabel('Class')
    plt.ylabel('Count')

    plt.savefig('categorical_plot.png')
    plt.close()
    

def plot_statistical_plot(df):
    """
    Plots a box plot to visualize the distribution of features (excluding the target variable).

    Parameters:
        df (pd.DataFrame): The dataset for plotting, excluding the target column 'class'.

    Saves:
        Saves the plot as 'statistical_plot.png'.
    """
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=df.drop(columns='class'), palette='Set2')
    plt.title('Distribution of Features (Box Plot)')
    plt.xlabel('Features')
    plt.ylabel('Value')
    plt.savefig('statistical_plot.png')
    plt.close()
    

def statistical_analysis(df, col: str):
    """
    Computes statistical moments for a given column in the dataset.

    Parameters:
        df (pd.DataFrame): The dataset.
        col (str): The column for which statistical analysis is performed.

    Returns:
        tuple: Mean, Standard Deviation, Skewness, and Excess Kurtosis.
    """
    mean = df[col].mean()
    stddev = df[col].std()
    skew = ss.skew(df[col])
    excess_kurtosis = ss.kurtosis(df[col])
    return mean, stddev, skew, excess_kurtosis


def preprocessing(df):
    """
    Preprocesses the dataset by performing the following tasks:
    - Handling missing values (if any).
    - Basic exploration using describe, head, and corr.
    - Encoding categorical variables (if any).
    - Scaling numerical features for consistency.

    Parameters:
        df (pd.DataFrame): The dataset to preprocess.

    Returns:
        pd.DataFrame: The preprocessed dataset.
    """
    # 1. Check for missing values and handle them (drop or impute)
    if df.isnull().sum().any():
        print("Missing values found, filling with the mean value of each column.")
        df = df.fillna(df.mean())  # Filling missing values with column mean (for numerical columns)
    df2 = df[['sepal length', 'sepal width', 'petal length', 'petal width']].copy()
    # 2. Basic exploration using describe(), head(), and corr()
    print(df.describe())  # Get basic statistics of the numerical columns
    print(df.head())  # Get first few rows of data to understand its structure
    print(df2.corr())  # Check correlations between numeric features

    # 3. Encoding categorical variables (in this case, 'class' column)
    label_encoder = LabelEncoder()
    df['class'] = label_encoder.fit_transform(df['class'])

    # 4. Scaling numerical features (StandardScaler)
    features = ['sepal length', 'sepal width', 'petal length', 'petal width']
    scaler = StandardScaler()
    df[features] = scaler.fit_transform(df[features])

    # 5. Return the preprocessed dataset
    return df


def writing(moments, col):
    """
    Prints statistical information about the given attribute.

    Parameters:
        moments (tuple): A tuple containing the mean, standard deviation, skewness, and excess kurtosis.
        col (str): The name of the column being analyzed.

    Returns:
        None
    """
    mean, stddev, skew, excess_kurtosis = moments

    print(f'For the attribute {col}:')
    print(f'Mean = {mean:.2f}, '
          f'Standard Deviation = {stddev:.2f}, '
          f'Skewness = {skew:.2f}, and '
          f'Excess Kurtosis = {excess_kurtosis:.2f}.')

    # Check skewness and kurtosis categories
    if skew > 0:
        skewness_type = 'right'
    elif skew < 0:
        skewness_type = 'left'
    else:
        skewness_type = 'not'

    if excess_kurtosis > 0:
        kurtosis_type = 'leptokurtic'
    elif excess_kurtosis < 0:
        kurtosis_type = 'platykurtic'
    else:
        kurtosis_type = 'mesokurtic'

    print(f'The data was {skewness_type} skewed and {kurtosis_type}.')
    

def perform_clustering(df, col1, col2):
    """
    Perform clustering on two features from the dataset and visualize the results.

    Parameters:
        df (pd.DataFrame): The dataset to perform clustering on.
        col1 (str): The first column to use for clustering.
        col2 (str): The second column to use for clustering.

    Returns:
        labels (array): The cluster labels for each data point.
        data (array): The feature data used for clustering.
        xkmeans (array): The x coordinates of the cluster centers.
        ykmeans (array): The y coordinates of the cluster centers.
        cenlabels (array): The labels of the cluster centers.
    """


    # Step 1: Gather data for clustering
    data = df[[col1, col2]].values  # Extract the two features
    x = data[:, 0]  # Extract x feature (col1)
    y = data[:, 1]  # Extract y feature (col2)

    def plot_elbow_method():
        """
        Plots the elbow method to determine the optimal number of clusters.

        Saves:
            Elbow plot as 'elbow_plot.png'.
        """
        inertia = []
        k_range = range(1, 11)  # Trying k from 1 to 10 clusters
        for k in k_range:
            kmeans = KMeans(n_clusters=k, random_state=42)
            kmeans.fit(data)
            inertia.append(kmeans.inertia_)
        
        # Plot Elbow Curve
        plt.figure(figsize=(6, 6))
        plt.plot(k_range, inertia, marker='o', linestyle='--', color='b')
        plt.title('Elbow Method for Optimal k')
        plt.xlabel('Number of clusters (k)')
        plt.ylabel('Inertia')
        plt.savefig('elbow_plot.png')
        plt.close()
        

    def one_silhouette_inertia():
        """
        Finds the optimal number of clusters using the silhouette score.

        Returns:
            _score (float): The highest silhouette score.
            _inertia (float): The inertia corresponding to the best number of clusters.
        """
        silhouette_scores = []
        inertia_values = []
        k_range = range(2, 11)  # Start from k=2 as silhouette is not defined for k=1

        for k in k_range:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = kmeans.fit_predict(data)
            score = silhouette_score(data, labels)
            silhouette_scores.append(score)
            inertia_values.append(kmeans.inertia_)

        # Get the best score and corresponding inertia
        optimal_index = silhouette_scores.index(max(silhouette_scores))
        _score = silhouette_scores[optimal_index]
        _inertia = inertia_values[optimal_index]
        return _score, _inertia

    # Step 2: Determine the optimal number of clusters
    _score, _inertia = one_silhouette_inertia()
    plot_elbow_method()

    # Step 3: Apply KMeans clustering with optimal k
    optimal_k = np.argmax([silhouette_score(data, KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(data)) for k in range(2, 11)]) + 2
    kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
    labels = kmeans.fit_predict(data)

    # Step 4: Extract cluster centers
    cluster_centers = kmeans.cluster_centers_
    xkmeans = cluster_centers[:, 0]  # X coordinates of cluster centers
    ykmeans = cluster_centers[:, 1]  # Y coordinates of cluster centers
    cenlabels = np.arange(len(cluster_centers))  # Labels for cluster centers
    # Get cluster centers
    return labels, data, xkmeans, ykmeans, cenlabels


def plot_clustered_data(labels, data, xkmeans, ykmeans, centre_labels):
    """
    Plots clustered data with different colors for each cluster and marks cluster centers.

    Parameters:
        labels (array): Cluster labels for each data point.
        data (array): Feature data used for clustering.
        xkmeans (array): X coordinates of the cluster centers.
        ykmeans (array): Y coordinates of the cluster centers.
        centre_labels (array): Labels of the cluster centers.

    Saves:
        Saves the plot as 'clustering.png'.
    """
    # Extract x and y values from data
    x = data[:, 0]
    y = data[:, 1]

    # Create figure
    plt.figure(figsize=(8, 6))

    # Scatter plot for clustered points
    scatter = sns.scatterplot(x=x, y=y, hue=labels, palette='viridis', legend='full')

    # Plot cluster centers
    plt.scatter(xkmeans, ykmeans, c='red', marker='X', s=200, label='Cluster Centers')

    # Annotate cluster centers
    for i, (cx, cy) in enumerate(zip(xkmeans, ykmeans)):
        plt.text(cx, cy, str(centre_labels[i]), fontsize=12, fontweight='bold', ha='center', va='center', color='white',
                 bbox=dict(facecolor='black', edgecolor='white', boxstyle='round,pad=0.3'))

    # Labels and title
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.title('Clustered Data Visualization')
    plt.legend()
    
    # Save the plot
    plt.savefig('clustering.png')
    plt.close()
    
def perform_fitting(df, col1, col2):
    """
    Performs linear regression fitting between two selected features.

    Parameters:
        df (pd.DataFrame): The dataset containing the features.
        col1 (str): The independent variable (feature for prediction).
        col2 (str): The dependent variable (target).

    Returns:
        data (array): Feature-target data used for fitting.
        x (array): Scaled feature values reshaped for model fitting.
        y (array): Corresponding target values.
    """
    # Extracting required columns
    x = df[[col1]].values  # Independent variable (feature) (2D array)
    y = df[col2].values  # Dependent variable (target) (1D array)

    # Apply Scaling to x
    scaler = StandardScaler()
    x = scaler.fit_transform(x).flatten()  # Ensure 1D after scaling

    # Fit Linear Regression Model
    model = LinearRegression()
    model.fit(x.reshape(-1, 1), y)

    # Predict values across x for plotting
    y_pred = model.predict(x.reshape(-1, 1))

    # Preparing data for return
    data = np.column_stack((x, y_pred))  # Combine x and predicted y

    return data, x, y


def plot_fitted_data(data, x, y):
    """
    Plots the fitted regression line against the actual data.

    Parameters:
        data (array): Feature-target data used for fitting.
        x (array): Feature values used for fitting.
        y (array): Corresponding target values.

    Saves:
        Saves the plot as 'fitting.png'.
    """
    plt.figure(figsize=(8, 6))

    # Scatter plot for actual data
    sns.scatterplot(x=x.flatten(), y=y, color='blue', label='Actual Data')

    # Regression Line
    sns.lineplot(x=data[:, 0], y=data[:, 1], color='red', label='Fitted Line')

    # Labels and Title
    plt.xlabel('Feature (Independent Variable)')
    plt.ylabel('Target (Dependent Variable)')
    plt.title('Fitted Regression Line')
    plt.legend()

    # Save the plot
    plt.savefig('fitting.png')
    plt.close()
    

def main():
    df = pd.read_csv('data.csv')
    df = preprocessing(df)
    col = 'sepal width'
    plot_relational_plot(df)
    plot_statistical_plot(df)
    plot_categorical_plot(df)
    moments = statistical_analysis(df, col)
    writing(moments, col)
    clustering_results = perform_clustering(df, 'sepal length', 'sepal width')
    plot_clustered_data(*clustering_results)
    fitting_results = perform_fitting(df, 'sepal length', 'petal length')
    plot_fitted_data(*fitting_results)
    return


if __name__ == '__main__':
    main()